@echo off
rem DeadEnd CLI -- prefers the Python that ships with the DeadEnd installer.
if exist "%~dp0tools\python\python.exe" (
  "%~dp0tools\python\python.exe" "%~dp0src\dec.py" %*
) else (
  py -3 "%~dp0src\dec.py" %* || python "%~dp0src\dec.py" %*
)

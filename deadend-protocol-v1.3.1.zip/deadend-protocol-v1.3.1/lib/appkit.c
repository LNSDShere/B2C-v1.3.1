/* ==========================================================================
 * DeadEnd App Dev Kit -- appkit.c  (built on raylib 5.5)
 * ========================================================================== */
#include "appkit.h"
#include "gamekit.h"
#include "raylib.h"
#include <stdlib.h>

static const char *dep_cstr_of(DEPValue v, const char *what) {
    if (v.tag != DEP_T_TEXT)
        dep_die("%s needs the widget's name in text, got %s", what, dep_typename(v));
    return v.as.s->chars;
}

#define DEP_MAX_WIDGETS 256
#define DEP_FIELD_MAX 1024

typedef struct {
    int type;
    char name[128];
    double x, y, w, h;
    char *text;            /* field content / label text (heap) */
    long text_len, text_cap;
    int checked;           /* checkbox */
    double value;          /* slider 0..100 */
    Texture2D tex;
    int has_tex;
} DEPWidget;

static DEPWidget dep_widgets[DEP_MAX_WIDGETS];
static int dep_widget_count = 0;
static int dep_app_focus = -1;      /* focused field index */
static void (*dep_app_cbs[DEP_MAX_WIDGETS])(void);
static int dep_app_cursor_blink = 0;

static char dep_app_title[256] = "DeadEnd App";
static int dep_app_w = 480, dep_app_h = 320;

void dep_app_setup(DEPValue title, double w, double h) {
    if (title.tag == DEP_T_TEXT) {
        long n = title.as.s->len;
        if (n > 255) n = 255;
        memcpy(dep_app_title, title.as.s->chars, (size_t)n);
        dep_app_title[n] = '\0';
    }
    if (w > 0) dep_app_w = (int)w;
    if (h > 0) dep_app_h = (int)h;
    dep_release(title);
}

static DEPWidget *dep_widget_by_name(const char *name) {
    for (int i = 0; i < dep_widget_count; i++)
        if (strcmp(dep_widgets[i].name, name) == 0) return &dep_widgets[i];
    return NULL;
}

void dep_app_add(int type, const char *name, double x, double y, double w, double h) {
    if (dep_widget_count >= DEP_MAX_WIDGETS) {
        dep_die("this app has too many widgets (limit %d)", DEP_MAX_WIDGETS);
    }
    if (dep_widget_by_name(name)) {
        dep_die("there is already a widget called \"%s\" -- widget names must "
                "be unique", name);
    }
    DEPWidget *g = &dep_widgets[dep_widget_count];
    memset(g, 0, sizeof(DEPWidget));
    g->type = type;
    long n = (long)strlen(name);
    if (n > 127) n = 127;
    memcpy(g->name, name, (size_t)n);
    g->name[n] = '\0';
    g->x = x; g->y = y;
    /* sensible defaults */
    double dw = w, dh = h;
    if (dw < 0) {
        switch (type) {
            case DEP_W_TITLE:  dw = 400; break;
            case DEP_W_LABEL:  dw = MeasureText(name, 20) + 8; break;
            case DEP_W_BUTTON: dw = MeasureText(name, 20) + 32; break;
            case DEP_W_FIELD:  dw = 200; break;
            case DEP_W_CHECKBOX: dw = 20; break;
            case DEP_W_SLIDER: dw = 160; break;
            case DEP_W_IMAGE:  dw = 100; break;
            case DEP_W_PANEL:  dw = 200; break;
            default: dw = 100;
        }
    }
    if (dh < 0) {
        switch (type) {
            case DEP_W_TITLE:  dh = 34; break;
            case DEP_W_LABEL:  dh = 24; break;
            case DEP_W_BUTTON: dh = 34; break;
            case DEP_W_FIELD:  dh = 28; break;
            case DEP_W_CHECKBOX: dh = 20; break;
            case DEP_W_SLIDER: dh = 20; break;
            case DEP_W_IMAGE:  dh = 100; break;
            case DEP_W_PANEL:  dh = 120; break;
            default: dh = 24;
        }
    }
    g->w = dw; g->h = dh;
    g->text_cap = 64;
    g->text = (char *)malloc(64);
    g->text[0] = '\0';
    g->text_len = 0;
    if (type == DEP_W_IMAGE) {
        g->tex = LoadTexture(name);
        g->has_tex = 1;
        if (w < 0) g->w = g->tex.width;
        if (h < 0) g->h = g->tex.height;
    }
    dep_widget_count++;
}

void dep_app_on_click(const char *name, void (*fn)(void)) {
    for (int i = 0; i < dep_widget_count; i++) {
        if (strcmp(dep_widgets[i].name, name) == 0 && dep_widgets[i].type == DEP_W_BUTTON) {
            dep_app_cbs[i] = fn;
            return;
        }
    }
    DEPWidget *g = dep_widget_by_name(name);
    if (!g) {
        dep_die("there is no button called \"%s\" (add it first with "
                "'add button \"%s\" ...')", name, name);
    }
}

/* ---------------- reading / writing widget values ---------------- */
static DEPWidget *dep_widget_or_die(const char *name, int type, const char *what) {
    DEPWidget *g = dep_widget_by_name(name);
    if (!g) dep_die("there is no %s called \"%s\"", what, name);
    if (g->type != type) dep_die("\"%s\" is not a %s", name, what);
    return g;
}

DEPStr *dep_a_field(DEPValue name) {
    DEPWidget *g = dep_widget_or_die(dep_cstr_of(name, "field"), DEP_W_FIELD, "field");
    DEPStr *r = dep_str_new(g->text, g->text_len);
    dep_release(name);
    return r;
}

DEPStr *dep_a_label(DEPValue name) {
    DEPWidget *g = dep_widget_or_die(dep_cstr_of(name, "label"), DEP_W_LABEL, "label");
    const char *t = g->text[0] ? g->text : g->name;
    DEPStr *r = dep_str_new(t, (long)strlen(t));
    dep_release(name);
    return r;
}

int dep_a_checkbox(DEPValue name) {
    DEPWidget *g = dep_widget_or_die(dep_cstr_of(name, "checkbox"), DEP_W_CHECKBOX, "checkbox");
    dep_release(name);
    return g->checked;
}

double dep_a_slider(DEPValue name) {
    DEPWidget *g = dep_widget_or_die(dep_cstr_of(name, "slider"), DEP_W_SLIDER, "slider");
    dep_release(name);
    return g->value;
}

void dep_app_set_text(const char *name, DEPValue text) {
    DEPWidget *g = dep_widget_by_name(name);
    if (!g) { dep_release(text); return; }
    if (g->type == DEP_W_FIELD) {
        const char *s = (text.tag == DEP_T_TEXT) ? text.as.s->chars : "";
        long n = (text.tag == DEP_T_TEXT) ? text.as.s->len : 0;
        if (n > DEP_FIELD_MAX - 1) n = DEP_FIELD_MAX - 1;
        if ((long)g->text_cap < n + 1) {
            while ((long)g->text_cap < n + 1) g->text_cap *= 2;
            g->text = (char *)realloc(g->text, (size_t)g->text_cap);
        }
        memcpy(g->text, s, (size_t)n);
        g->text[n] = '\0';
        g->text_len = n;
    } else if (g->type == DEP_W_LABEL || g->type == DEP_W_BUTTON) {
        const char *s = (text.tag == DEP_T_TEXT) ? text.as.s->chars : "";
        long n = (text.tag == DEP_T_TEXT) ? text.as.s->len : 0;
        free(g->text);
        g->text_cap = n + 8;
        g->text = (char *)malloc((size_t)g->text_cap);
        memcpy(g->text, s, (size_t)n);
        g->text[n] = '\0';
        g->text_len = n;
    }
    dep_release(text);
}

void dep_app_set_val(const char *name, DEPValue val) {
    DEPWidget *g = dep_widget_by_name(name);
    if (!g) { dep_release(val); return; }
    if (g->type == DEP_W_CHECKBOX) {
        g->checked = dep_truthy(val);
    } else if (g->type == DEP_W_SLIDER) {
        g->value = (val.tag == DEP_T_NUM) ? val.as.n : 0;
        if (g->value < 0) g->value = 0;
        if (g->value > 100) g->value = 100;
    }
    dep_release(val);
}

/* ---------------- interaction + run ---------------- */
static int dep_hit(DEPWidget *g, double mx, double my) {
    return mx >= g->x && mx <= g->x + g->w && my >= g->y && my <= g->y + g->h;
}

static void dep_field_type(DEPWidget *g) {
    int c = GetCharPressed();
    while (c > 0) {
        if (c >= 32 && c < 127 && g->text_len < DEP_FIELD_MAX - 1) {
            if ((long)g->text_cap < g->text_len + 2) {
                g->text_cap *= 2;
                g->text = (char *)realloc(g->text, (size_t)g->text_cap);
            }
            g->text[g->text_len++] = (char)c;
            g->text[g->text_len] = '\0';
        }
        c = GetCharPressed();
    }
    if (IsKeyPressed(KEY_BACKSPACE) && g->text_len > 0) {
        g->text[--g->text_len] = '\0';
    }
}

void dep_app_run(void) {
    SetTraceLogLevel(LOG_WARNING);
    InitWindow(dep_app_w, dep_app_h, dep_app_title);
    SetTargetFPS(60);
    dep_window_open = 1;
    long limit = -1;
    const char *fl = getenv("DEP_FRAMES");
    if (fl) limit = atol(fl);
    long n = 0;
    while (!WindowShouldClose()) {
        double mx = GetMouseX(), my = GetMouseY();
        int clicked = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
        int down = IsMouseButtonDown(MOUSE_BUTTON_LEFT);
        BeginDrawing();
        ClearBackground((Color) { 242, 244, 248, 255 });
        dep_app_cursor_blink = (dep_app_cursor_blink + 1) % 60;
        for (int i = 0; i < dep_widget_count; i++) {
            DEPWidget *g = &dep_widgets[i];
            int hover = dep_hit(g, mx, my);
            switch (g->type) {
                case DEP_W_PANEL:
                    DrawRectangle((int)g->x, (int)g->y, (int)g->w, (int)g->h,
                                  (Color) { 226, 230, 238, 255 });
                    DrawRectangleLines((int)g->x, (int)g->y, (int)g->w, (int)g->h,
                                       (Color) { 205, 210, 220, 255 });
                    break;
                case DEP_W_TITLE:
                    DrawText(g->text[0] ? g->text : g->name, (int)g->x, (int)g->y, 28,
                             (Color) { 25, 30, 45, 255 });
                    break;
                case DEP_W_LABEL:
                    DrawText(g->text[0] ? g->text : g->name, (int)g->x, (int)g->y, 20,
                             (Color) { 45, 50, 65, 255 });
                    break;
                case DEP_W_BUTTON: {
                    Color base = hover ? (Color) { 41, 128, 185, 255 }
                                       : (Color) { 52, 152, 219, 255 };
                    if (hover && down) base = (Color) { 31, 97, 141, 255 };
                    DrawRectangle((int)g->x, (int)g->y, (int)g->w, (int)g->h, base);
                    DrawRectangleLines((int)g->x + 1, (int)g->y + 1, (int)g->w - 2,
                                       (int)g->h - 2, (Color) { 30, 90, 130, 255 });
                    const char *t = g->text[0] ? g->text : g->name;
                    int tw = MeasureText(t, 20);
                    DrawText(t, (int)(g->x + (g->w - tw) / 2),
                             (int)(g->y + (g->h - 20) / 2), 20, WHITE);
                    break;
                }
                case DEP_W_FIELD: {
                    Color bg = (dep_app_focus == i) ? WHITE : (Color) { 250, 250, 252, 255 };
                    DrawRectangle((int)g->x, (int)g->y, (int)g->w, (int)g->h, bg);
                    DrawRectangleLines((int)g->x, (int)g->y, (int)g->w, (int)g->h,
                                       (dep_app_focus == i) ? (Color) { 52, 152, 219, 255 }
                                                            : (Color) { 190, 196, 206, 255 });
                    DrawText(g->text, (int)g->x + 8, (int)g->y + 5, 20,
                             (Color) { 35, 40, 55, 255 });
                    if (dep_app_focus == i && dep_app_cursor_blink < 30) {
                        int cx = (int)g->x + 8 + MeasureText(g->text, 20);
                        DrawText("|", cx, (int)g->y + 5, 20,
                                 (Color) { 52, 152, 219, 255 });
                    }
                    break;
                }
                case DEP_W_CHECKBOX: {
                    DrawRectangle((int)g->x, (int)g->y, (int)g->w, (int)g->h, WHITE);
                    DrawRectangleLines((int)g->x, (int)g->y, (int)g->w, (int)g->h,
                                       (Color) { 120, 126, 140, 255 });
                    if (g->checked)
                        DrawText("X", (int)g->x + 4, (int)g->y + 1, 16,
                                 (Color) { 39, 174, 96, 255 });
                    DrawText(g->name, (int)g->x + g->w + 8, (int)g->y + 1, 16,
                             (Color) { 45, 50, 65, 255 });
                    break;
                }
                case DEP_W_SLIDER: {
                    int ty = (int)(g->y + g->h / 2 - 2);
                    DrawRectangle((int)g->x, ty, (int)g->w, 4,
                                  (Color) { 200, 205, 215, 255 });
                    int kx = (int)(g->x + (g->w - 12) * (g->value / 100.0));
                    DrawRectangle(kx, (int)g->y, 12, (int)g->h,
                                  hover ? (Color) { 41, 128, 185, 255 }
                                        : (Color) { 90, 100, 120, 255 });
                    DrawText(g->name, (int)g->x, (int)g->y + g->h + 4, 14,
                             (Color) { 90, 96, 110, 255 });
                    break;
                }
                case DEP_W_IMAGE:
                    if (g->has_tex)
                        DrawTexture(g->tex, (int)g->x, (int)g->y, WHITE);
                    break;
            }
            /* interaction */
            if (clicked && hover) {
                switch (g->type) {
                    case DEP_W_BUTTON:
                        if (dep_app_cbs[i]) dep_app_cbs[i]();
                        break;
                    case DEP_W_FIELD:
                        dep_app_focus = i;
                        break;
                    case DEP_W_CHECKBOX:
                        g->checked = !g->checked;
                        break;
                    default:
                        break;
                }
            }
            if (g->type == DEP_W_FIELD && dep_app_focus == i)
                dep_field_type(g);
            if (g->type == DEP_W_SLIDER && down && hover) {
                double rel = (mx - g->x) / (g->w > 0 ? g->w : 1);
                if (rel < 0) rel = 0;
                if (rel > 1) rel = 1;
                g->value = rel * 100;
            }
        }
        EndDrawing();
        if (limit > 0 && ++n >= limit) break;
    }
    CloseWindow();
    dep_window_open = 0;
}
